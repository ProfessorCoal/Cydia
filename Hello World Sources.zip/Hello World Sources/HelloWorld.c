

















/* Hello World program */

#include<stdio.h>

int main(int argc, char **argv)
{
    printf("Hello World");

}
